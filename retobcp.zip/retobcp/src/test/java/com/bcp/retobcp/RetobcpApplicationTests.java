package com.bcp.retobcp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetobcpApplicationTests {

	@Test
	void contextLoads() {
	}

}
